package pe.angela.dokimimo;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/** Conexión con la misma nube (Firebase) que usan Doki y Mimo. */
public class Api {
    static final String KEY = "AIzaSyCJGZWNmAp9NcyoLtgtuE5h9g1WRj6MKHo";
    static final String PROJECT = "doki-angela";
    static final String SITE = "https://doki-angela.netlify.app/";

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("dm", Context.MODE_PRIVATE); }

    static String http(String method, String url, String body, String type, String bearer) throws Exception {
        HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
        h.setRequestMethod(method);
        h.setConnectTimeout(15000);
        h.setReadTimeout(20000);
        if (bearer != null) h.setRequestProperty("Authorization", "Bearer " + bearer);
        if (body != null) {
            h.setDoOutput(true);
            h.setRequestProperty("Content-Type", type);
            OutputStream o = h.getOutputStream();
            o.write(body.getBytes("UTF-8"));
            o.close();
        }
        int code = h.getResponseCode();
        InputStream in = code < 400 ? h.getInputStream() : h.getErrorStream();
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while (in != null && (n = in.read(buf)) > 0) b.write(buf, 0, n);
        String s = b.toString("UTF-8");
        if (code >= 400) throw new Exception("HTTP " + code + ": " + s);
        return s;
    }

    /** Entra con el mismo correo y contraseña de las apps. Devuelve null si todo salió bien, o el mensaje de error. */
    static String login(Context c, String email, String pass) {
        try {
            JSONObject req = new JSONObject();
            req.put("email", email);
            req.put("password", pass);
            req.put("returnSecureToken", true);
            JSONObject r = new JSONObject(http("POST", "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" + KEY, req.toString(), "application/json", null));
            prefs(c).edit().putString("uid", r.getString("localId")).putString("rt", r.getString("refreshToken"))
                    .putString("it", r.getString("idToken")).putLong("itAt", System.currentTimeMillis()).putString("email", email).apply();
            return null;
        } catch (Exception e) {
            String m = String.valueOf(e.getMessage());
            if (m.contains("INVALID") || m.contains("PASSWORD") || m.contains("EMAIL_NOT_FOUND")) return "Correo o contraseña incorrectos.";
            if (m.contains("TOO_MANY")) return "Muchos intentos. Espera un ratito.";
            return "No pude conectarme. Revisa tu internet.";
        }
    }

    static String token(Context c) throws Exception {
        SharedPreferences p = prefs(c);
        String it = p.getString("it", null);
        if (it != null && System.currentTimeMillis() - p.getLong("itAt", 0) < 50 * 60 * 1000) return it;
        String rt = p.getString("rt", null);
        if (rt == null) throw new Exception("sin sesión");
        JSONObject r = new JSONObject(http("POST", "https://securetoken.googleapis.com/v1/token?key=" + KEY,
                "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(rt, "UTF-8"), "application/x-www-form-urlencoded", null));
        it = r.getString("id_token");
        p.edit().putString("it", it).putString("rt", r.getString("refresh_token")).putLong("itAt", System.currentTimeMillis()).apply();
        return it;
    }

    /** Trae lo que Doki y Mimo dejaron para los widgets. */
    static boolean fetch(Context c) {
        SharedPreferences p = prefs(c);
        String uid = p.getString("uid", null);
        if (uid == null) return false;
        boolean ok = false;
        for (String app : new String[]{"doki", "mimi"}) {
            try {
                String url = "https://firestore.googleapis.com/v1/projects/" + PROJECT + "/databases/(default)/documents/users/" + uid + "/push/w_" + app;
                JSONObject d = new JSONObject(http("GET", url, null, null, token(c)));
                String j = d.getJSONObject("fields").getJSONObject("j").getString("stringValue");
                p.edit().putString("w_" + app, j).putLong("got", System.currentTimeMillis()).apply();
                ok = true;
            } catch (Exception e) {
                p.edit().putString("err", String.valueOf(e.getMessage())).apply();
            }
        }
        return ok;
    }

    static JSONObject data(Context c, String app) {
        try { return new JSONObject(prefs(c).getString("w_" + app, "{}")); } catch (Exception e) { return new JSONObject(); }
    }
}
