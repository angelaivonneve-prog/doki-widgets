package pe.angela.dokimimo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

/** Lo que pasa cuando tocas algo dentro de un widget, sin abrir la app. */
public class Acciones extends BroadcastReceiver {
    static final String HABITO = "pe.angela.dokimimo.HABITO", AGUA = "pe.angela.dokimimo.AGUA", MOCHILA = "pe.angela.dokimimo.MOCHILA";

    @Override public void onReceive(Context c, Intent i) {
        final PendingResult pr = goAsync();
        final Context a = c.getApplicationContext();
        final String act = i.getAction(), id = i.getStringExtra("id");
        new Thread(() -> {
            String msg = null;
            try {
                if (HABITO.equals(act)) msg = habito(a, id);
                else if (AGUA.equals(act)) msg = agua(a);
                else if (MOCHILA.equals(act)) msg = mochila(a);
            } catch (Exception e) { msg = "Sin internet: inténtalo de nuevo 🐾"; }
            Widgets.renderAll(a);
            final String m = msg;
            if (m != null) new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> Toast.makeText(a, m, Toast.LENGTH_SHORT).show());
            pr.finish();
        }).start();
    }

    static String habito(Context c, String id) throws Exception {
        String td = Widgets.today();
        JSONObject w = Api.data(c, "mimi");
        JSONArray hs = w.optJSONArray("habits");
        JSONObject h = null;
        for (int k = 0; hs != null && k < hs.length(); k++) if (id.equals(hs.getJSONObject(k).optString("id"))) h = hs.getJSONObject(k);
        if (h == null) return null;
        JSONObject log = Api.getDoc(c, "habit-log");
        if (log == null) log = new JSONObject();
        JSONObject d = log.optJSONObject("d");
        if (d == null) { d = new JSONObject(); log.put("d", d); }
        JSONArray day = d.optJSONArray(td);
        if (day == null) { day = new JSONArray(); d.put(td, day); }
        int tg = Math.max(1, h.optInt("tg", 1));
        boolean was = false;
        for (int k = 0; k < day.length(); k++) if (id.equals(day.optString(k))) was = true;
        String msg;
        if (tg > 1) {
            JSONObject cc = log.optJSONObject("c");
            if (cc == null) { cc = new JSONObject(); log.put("c", cc); }
            JSONObject cd = cc.optJSONObject(td);
            if (cd == null) { cd = new JSONObject(); cc.put(td, cd); }
            int n = cd.optInt(id, 0) + 1;
            if (n > tg) n = 0;
            cd.put(id, n);
            JSONArray nd = new JSONArray();
            for (int k = 0; k < day.length(); k++) if (!id.equals(day.optString(k))) nd.put(day.optString(k));
            if (n >= tg) nd.put(id);
            d.put(td, nd);
            h.put("k", n);
            h.put("d", n >= tg);
            msg = n >= tg ? "¡" + clean(h.optString("n")) + " completo! 🐾" : clean(h.optString("n")) + ": " + n + "/" + tg;
        } else if (was) {
            JSONArray nd = new JSONArray();
            for (int k = 0; k < day.length(); k++) if (!id.equals(day.optString(k))) nd.put(day.optString(k));
            d.put(td, nd);
            h.put("d", false);
            msg = "Desmarcado";
        } else {
            day.put(id);
            h.put("d", true);
            msg = "¡Hecho! +10 XP para Mimo 💗";
        }
        Api.putDoc(c, "habit-log", log);
        int done = 0;
        for (int k = 0; k < hs.length(); k++) if (hs.getJSONObject(k).optBoolean("d")) done++;
        w.put("hd", done);
        if (h.optBoolean("d") && !was) { w.put("hot", true); if (!td.equals(w.optString("day"))) w.put("day", td); Api.reward(c, "mimi", 10, td); }
        Api.putWidget(c, "mimi", w);
        return msg;
    }

    static String agua(Context c) throws Exception {
        String td = Widgets.today(), n = "day-" + td;
        JSONObject day = Api.getDoc(c, n);
        if (day == null) { day = new JSONObject(); day.put("meals", new JSONArray()); day.put("water", 0); }
        int goal = Api.data(c, "doki").optInt("goal", 10);
        int w = Math.min(goal + 6, day.optInt("water", 0) + 1);
        day.put("water", w);
        Api.putDoc(c, n, day);
        JSONObject wd = Api.data(c, "doki");
        wd.put("w", w);
        wd.put("water", w + "/" + goal);
        if (td.equals(wd.optString("day"))) wd.put("hot", true);
        Api.putWidget(c, "doki", wd);
        Api.reward(c, "doki", 1, td);
        return w >= goal ? "¡Meta de agua cumplida! 💧🎉" : "💧 " + w + " de " + goal + " vasos";
    }

    static String mochila(Context c) throws Exception {
        JSONObject wd = Api.data(c, "doki");
        JSONObject al = wd.optJSONObject("alice");
        if (al == null) return null;
        String k = al.optString("k");
        JSONObject ag = Api.getDoc(c, "agenda");
        if (ag == null) return "Abre Doki una vez para preparar la mochila";
        JSONObject mo = ag.optJSONObject("mochila");
        if (mo == null) { mo = new JSONObject(); ag.put("mochila", mo); }
        boolean ready = !mo.optBoolean(k, false);
        if (ready) mo.put(k, true); else mo.remove(k);
        Api.putDoc(c, "agenda", ag);
        al.put("ready", ready);
        Api.putWidget(c, "doki", wd);
        return ready ? "🎒 ¡Mochila lista!" : "Mochila sin marcar";
    }

    static String clean(String s) { return s.replaceAll("^[^\\p{L}\\p{N}]+", "").trim(); }
}
