package pe.angela.dokimimo;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;

public class SemanaWidget extends AppWidgetProvider {
    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        Widgets.renderAll(c);
        SyncJob.schedule(c);
        SyncJob.now(c);
    }
}
