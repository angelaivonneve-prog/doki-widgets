package pe.angela.dokimimo;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Pantalla única: entrar con tu correo y ver cómo poner los widgets. */
public class MainActivity extends Activity {
    LinearLayout box;
    TextView status;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#FFF8EE"));
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = dp(22);
        box.setPadding(p, dp(36), p, p);
        sv.addView(box);
        setContentView(sv);
        draw();
    }

    int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(Color.parseColor("#3B2F3F"));
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(6), 0, dp(6));
        box.addView(t);
        return t;
    }

    Button button(String s, String bg) {
        Button bt = new Button(this);
        bt.setText(s);
        bt.setAllCaps(false);
        bt.setTextColor(Color.parseColor("#3B2F3F"));
        bt.setBackgroundColor(Color.parseColor(bg));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.topMargin = dp(10);
        box.addView(bt, lp);
        return bt;
    }

    void draw() {
        box.removeAllViews();
        LinearLayout pets = new LinearLayout(this);
        pets.setGravity(Gravity.CENTER);
        for (int r : new int[]{R.drawable.doki_saludando, R.drawable.mimo_saludando}) {
            ImageView iv = new ImageView(this);
            iv.setImageResource(r);
            pets.addView(iv, new LinearLayout.LayoutParams(dp(110), dp(110)));
        }
        box.addView(pets);
        text("Widgets de Doki y Mimo", 22, true).setGravity(Gravity.CENTER);
        String email = Api.prefs(this).getString("email", null);
        if (email == null) {
            text("Entra con el mismo correo y contraseña que usas en Doki y Mimo (Ajustes → Sincronizar).", 15, false);
            EditText e = new EditText(this);
            e.setHint("Tu correo");
            e.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS | InputType.TYPE_CLASS_TEXT);
            box.addView(e);
            EditText pw = new EditText(this);
            pw.setHint("Tu contraseña de las apps");
            pw.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            box.addView(pw);
            Button go = button("Entrar", "#F6B4C6");
            status = text("", 14, false);
            go.setOnClickListener(x -> {
                status.setText("Entrando…");
                String em = e.getText().toString().trim(), pa = pw.getText().toString();
                new Thread(() -> {
                    String err = Api.login(this, em, pa);
                    if (err == null) { Api.fetch(this); Widgets.renderAll(this); SyncJob.schedule(this); }
                    runOnUiThread(() -> { if (err != null) status.setText(err); else draw(); });
                }).start();
            });
        } else {
            text("✅ Conectada como " + email, 15, true);
            long got = Api.prefs(this).getLong("got", 0);
            text(got > 0 ? "Última actualización: hace " + Math.max(1, (System.currentTimeMillis() - got) / 60000) + " min" : "Aún no hay datos. Abre Doki y Mimo una vez con internet.", 14, false);
            text("Cómo poner un widget", 18, true);
            text("1. Mantén presionado un espacio vacío de tu pantalla de inicio.\n2. Toca «Widgets».\n3. Busca «Widgets Doki y Mimo» y arrastra el que quieras:\n   • Doki · Mi día (horario, Alice, pendientes, agua)\n   • Doki · Pendientes (tu lista y + Anotar)\n   • Doki · Racha 🔥\n   • Mimo · Hábitos de hoy\n   • Mimo · Racha 🔥\n\nSe actualizan solos cada 15 minutos y cada vez que abres Doki o Mimo.", 15, false);
            Button up = button("🔄 Actualizar ahora", "#FFE08A");
            up.setOnClickListener(x -> new Thread(() -> { boolean ok = Api.fetch(this); Widgets.renderAll(this); runOnUiThread(() -> { draw(); android.widget.Toast.makeText(this, ok ? "¡Listo!" : "No pude actualizar. Revisa tu internet.", android.widget.Toast.LENGTH_SHORT).show(); }); }).start());
            button("🐶 Abrir Doki", "#FFF0B8").setOnClickListener(x -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(Api.SITE + "doki/"))));
            button("🐱 Abrir Mimo", "#F3E8FF").setOnClickListener(x -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(Api.SITE + "mimo/"))));
            Button out = button("Salir", "#EEEEEE");
            out.setOnClickListener(x -> { Api.prefs(this).edit().clear().apply(); Widgets.renderAll(this); draw(); });
        }
    }
}
