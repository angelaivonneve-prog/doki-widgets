package pe.angela.dokimimo;

import android.app.Application;
import java.io.PrintWriter;
import java.io.StringWriter;

/** Si la app se cae, guarda el motivo para mostrarlo en la pantalla principal. */
public class App extends Application {
    @Override public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                String s = sw.toString();
                Api.prefs(this).edit().putString("crash", new java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.US).format(new java.util.Date()) + " · " + (s.length() > 1500 ? s.substring(0, 1500) : s)).commit();
            } catch (Throwable ignored) {}
            if (prev != null) prev.uncaughtException(t, e);
        });
    }
}
