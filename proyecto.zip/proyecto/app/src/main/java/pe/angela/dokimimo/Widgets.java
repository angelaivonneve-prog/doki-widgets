package pe.angela.dokimimo;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/** Dibuja los 4 widgets con lo último que guardaron las apps. */
public class Widgets {
    static final String[] DIAS = {"Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"};

    static PendingIntent open(Context c, String path, int req) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url(path)));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return PendingIntent.getActivity(c, req, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** Cada app vive en su propia dirección. */
    static String url(String path) {
        if (path.startsWith("mimo/")) return "https://mimo-angela.netlify.app/" + path.substring(5);
        if (path.startsWith("cuki/")) return "https://cuki-angela.netlify.app/" + path.substring(5);
        return Api.SITE + path;
    }

    static PendingIntent action(Context c, String act, String id, int req) {
        Intent i = new Intent(c, Acciones.class);
        i.setAction(act);
        if (id != null) i.putExtra("id", id);
        return PendingIntent.getBroadcast(c, req, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static RemoteViews agua(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.w_agua);
        JSONObject d = Api.data(c, "doki");
        boolean fresh = today().equals(d.optString("day"));
        int goal = d.optInt("goal", 10), w = fresh ? d.optInt("w", 0) : 0;
        v.setTextViewText(R.id.n, w + "/" + goal);
        v.setInt(R.id.bar, "setMax", goal);
        v.setInt(R.id.bar, "setProgress", Math.min(w, goal));
        v.setTextViewText(R.id.add, w >= goal ? "¡Meta! +1" : "+1 vaso");
        v.setOnClickPendingIntent(R.id.root, action(c, Acciones.AGUA, null, 41));
        v.setOnClickPendingIntent(R.id.add, action(c, Acciones.AGUA, null, 42));
        return v;
    }

    static RemoteViews alice(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.w_alice);
        JSONObject d = Api.data(c, "doki"), a = d.optJSONObject("alice");
        if (a == null) {
            v.setTextViewText(R.id.title, "🎒 Alice");
            v.setTextViewText(R.id.cs, "Abre Doki un momento para ver el horario de Alice.");
            v.setViewVisibility(R.id.btn, android.view.View.GONE);
        } else {
            JSONArray cs = a.optJSONArray("cs");
            boolean school = cs != null && cs.length() > 0;
            v.setTextViewText(R.id.title, "🎒 Alice · " + a.optString("lbl") + (school ? " · " + a.optString("h") : ""));
            StringBuilder s = new StringBuilder();
            for (int i = 0; cs != null && i < cs.length(); i++) s.append(i > 0 ? ", " : "").append(cs.optString(i));
            v.setTextViewText(R.id.cs, school ? s.toString() : "No tiene colegio 🎉");
            StringBuilder l = new StringBuilder();
            JSONArray ll = a.optJSONArray("lleva"), ts = a.optJSONArray("tasks");
            for (int i = 0; ll != null && i < ll.length(); i++) l.append("• ").append(ll.optString(i)).append("\n");
            for (int i = 0; ts != null && i < ts.length(); i++) l.append("📌 ").append(ts.optString(i)).append("\n");
            v.setTextViewText(R.id.lleva, l.toString().trim());
            v.setViewVisibility(R.id.btn, school ? android.view.View.VISIBLE : android.view.View.GONE);
            boolean ready = a.optBoolean("ready");
            v.setTextViewText(R.id.btn, ready ? "Mochila lista ✓" : "Marcar mochila lista");
            v.setOnClickPendingIntent(R.id.btn, action(c, Acciones.MOCHILA, null, 51));
        }
        v.setOnClickPendingIntent(R.id.root, open(c, "doki/?go=age:hoy", 52));
        return v;
    }

    static RemoteViews mover(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.w_mover);
        JSONObject d = Api.data(c, "mimi"), mv = d.optJSONObject("mv");
        boolean fresh = today().equals(d.optString("day"));
        if (mv == null) { v.setTextViewText(R.id.s, "Abre Mimo un momento 🐾"); }
        else if (fresh && mv.optBoolean("done")) {
            v.setTextViewText(R.id.em, "💪");
            v.setTextViewText(R.id.t, "¡Hecho hoy!");
            v.setTextViewText(R.id.s, "Racha Moverme: día " + mv.optInt("n"));
            v.setViewVisibility(R.id.btn, android.view.View.GONE);
        } else {
            v.setTextViewText(R.id.t, mv.optInt("min", 1) + " min");
            v.setTextViewText(R.id.s, fresh ? "Día " + mv.optInt("n") + " · " + mv.optString("lv") : "Tu reto de hoy");
            v.setViewVisibility(R.id.btn, android.view.View.VISIBLE);
        }
        v.setOnClickPendingIntent(R.id.root, open(c, "mimo/?do=move", 61));
        v.setOnClickPendingIntent(R.id.btn, open(c, "mimo/?do=move", 62));
        return v;
    }

    static String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }

    static int pet(String app, String img) {
        String k = img == null ? "feliz" : img;
        if (app.equals("cuki")) switch (k) {
            case "celebrando": return R.drawable.cuki_celebrando;
            case "pensativo": return R.drawable.cuki_pensativo;
            case "saludando": return R.drawable.cuki_saludando;
            case "triste": return R.drawable.cuki_triste;
            default: return R.drawable.cuki_feliz;
        }
        switch (k) {
            case "celebrando": return app.equals("doki") ? R.drawable.doki_celebrando : R.drawable.mimo_celebrando;
            case "pensativo": return app.equals("doki") ? R.drawable.doki_pensativo : R.drawable.mimo_pensativo;
            case "saludando": return app.equals("doki") ? R.drawable.doki_saludando : R.drawable.mimo_saludando;
            case "triste": return app.equals("doki") ? R.drawable.doki_triste : R.drawable.mimo_triste;
            default: return app.equals("doki") ? R.drawable.doki_feliz : R.drawable.mimo_feliz;
        }
    }

    static void renderAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        for (int id : m.getAppWidgetIds(new ComponentName(c, DiaWidget.class))) m.updateAppWidget(id, dia(c));
        for (int id : m.getAppWidgetIds(new ComponentName(c, PendWidget.class))) m.updateAppWidget(id, pend(c));
        for (int id : m.getAppWidgetIds(new ComponentName(c, AguaWidget.class))) m.updateAppWidget(id, agua(c));
        for (int id : m.getAppWidgetIds(new ComponentName(c, AliceWidget.class))) m.updateAppWidget(id, alice(c));
        for (int id : m.getAppWidgetIds(new ComponentName(c, MoverWidget.class))) m.updateAppWidget(id, mover(c));
        for (int id : m.getAppWidgetIds(new ComponentName(c, MimoWidget.class))) m.updateAppWidget(id, mimo(c));
        for (int id : m.getAppWidgetIds(new ComponentName(c, RachaDokiWidget.class))) m.updateAppWidget(id, racha(c, "doki"));
        for (int id : m.getAppWidgetIds(new ComponentName(c, RachaMimoWidget.class))) m.updateAppWidget(id, racha(c, "mimi"));
        Widgets2.renderAll(c);
    }

    static RemoteViews dia(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.w_dia);
        JSONObject d = Api.data(c, "doki");
        boolean fresh = today().equals(d.optString("day"));
        Calendar cal = Calendar.getInstance();
        int nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE);
        v.setTextViewText(R.id.title, DIAS[cal.get(Calendar.DAY_OF_WEEK) - 1] + " " + cal.get(Calendar.DAY_OF_MONTH));
        int st = fresh || isYesterday(d.optString("day")) ? d.optInt("st", 0) : 0;
        v.setTextViewText(R.id.fire, "🔥" + st);
        v.setImageViewResource(R.id.pet, pet("doki", d.optString("img")));
        int[] rows = {R.id.r0, R.id.r1, R.id.r2}, bars = {R.id.b0, R.id.b1, R.id.b2}, hs = {R.id.h0, R.id.h1, R.id.h2}, ns = {R.id.n0, R.id.n1, R.id.n2};
        JSONArray items = null;
        JSONObject week = d.optJSONObject("week");
        if (week != null) items = week.optJSONArray(String.valueOf(cal.get(Calendar.DAY_OF_WEEK) - 1));
        if (items == null && fresh) items = d.optJSONArray("items");
        int shown = 0, left = 0;
        if (items != null) for (int i = 0; i < items.length(); i++) {
            JSONObject it = items.optJSONObject(i);
            if (it == null || it.optInt("e", 99999) <= nowMin) continue;
            left++;
            if (shown >= 3) continue;
            v.setViewVisibility(rows[shown], android.view.View.VISIBLE);
            try { v.setInt(bars[shown], "setBackgroundColor", Color.parseColor(it.optString("c", "#F6B4C6"))); } catch (Exception ignored) {}
            boolean now = it.optInt("s", 0) <= nowMin;
            v.setTextViewText(hs[shown], now ? "Ahora" : it.optString("h"));
            v.setTextViewText(ns[shown], it.optString("n"));
            shown++;
        }
        for (int i = shown; i < 3; i++) v.setViewVisibility(rows[i], android.view.View.GONE);
        String extra;
        if (d.length() == 0) extra = "Abre esta app y entra con tu correo para ver tu día aquí.";
        else if (shown == 0) extra = "No te queda nada en el horario 🎉";
        else extra = left > 3 ? "+" + (left - 3) + " más hoy" : "";
        JSONArray tasks = fresh ? d.optJSONArray("tasks") : null;
        if (fresh && tasks != null && tasks.length() > 0 && shown < 3) extra = (extra.isEmpty() ? "" : extra + "\n") + "📝 " + tasks.optString(0);
        v.setTextViewText(R.id.extra, extra);
        v.setTextViewText(R.id.pend, "📝 " + (fresh ? d.optInt("pend", 0) : 0) + " pendientes");
        v.setTextViewText(R.id.water, "💧 " + (fresh ? d.optString("water", "0") : "0"));
        v.setOnClickPendingIntent(R.id.root, open(c, "doki/?go=age:hoy", 1));
        v.setOnClickPendingIntent(R.id.pend, open(c, "doki/?go=age:pend", 2));
        v.setOnClickPendingIntent(R.id.water, open(c, "doki/?do=water", 3));
        v.setOnClickPendingIntent(R.id.add, open(c, "doki/?new=task", 4));
        return v;
    }

    static RemoteViews pend(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.w_pend);
        JSONObject d = Api.data(c, "doki");
        String td = today();
        int[] rs = {R.id.p0, R.id.p1, R.id.p2, R.id.p3, R.id.p4, R.id.p5}, cs = {R.id.pc0, R.id.pc1, R.id.pc2, R.id.pc3, R.id.pc4, R.id.pc5},
              ts = {R.id.pt0, R.id.pt1, R.id.pt2, R.id.pt3, R.id.pt4, R.id.pt5}, ws = {R.id.pw0, R.id.pw1, R.id.pw2, R.id.pw3, R.id.pw4, R.id.pw5};
        JSONArray tl = d.optJSONArray("tl");
        int n = 0, late = 0, total = tl == null ? 0 : tl.length();
        for (int i = 0; tl != null && i < tl.length(); i++) {
            JSONObject t = tl.optJSONObject(i);
            if (t == null) continue;
            boolean isLate = t.optString("d").compareTo(td) < 0;
            if (isLate) late++;
            if (n >= 6) continue;
            v.setViewVisibility(rs[n], android.view.View.VISIBLE);
            try { v.setInt(cs[n], "setBackgroundColor", Color.parseColor(t.optString("c", "#F6B4C6"))); } catch (Exception ignored) {}
            v.setTextViewText(ts[n], t.optString("t"));
            String when = whenLabel(t.optString("d"), td) + (t.optString("h").isEmpty() ? "" : " · " + t.optString("h"));
            v.setTextViewText(ws[n], when);
            v.setTextColor(ws[n], isLate ? Color.parseColor("#D9363E") : Color.parseColor("#6E6873"));
            n++;
        }
        for (int i = n; i < 6; i++) v.setViewVisibility(rs[i], android.view.View.GONE);
        v.setTextViewText(R.id.title, total == 0 ? "Pendientes" : "Pendientes · " + total + (late > 0 ? " (" + late + " atrasado" + (late == 1 ? "" : "s") + ")" : ""));
        v.setTextViewText(R.id.empty, d.length() == 0 ? "Abre esta app y entra con tu correo para ver tus pendientes." : total == 0 ? "¡Nada pendiente! 🎉 Toca + Anotar para agregar algo." : total > 6 ? "+" + (total - 6) + " más" : "");
        v.setImageViewResource(R.id.pet, pet("doki", late > 0 ? "pensativo" : total == 0 ? "celebrando" : "feliz"));
        v.setOnClickPendingIntent(R.id.root, open(c, "doki/?go=age:pend", 31));
        v.setOnClickPendingIntent(R.id.add, open(c, "doki/?new=task", 32));
        return v;
    }

    static String whenLabel(String d, String td) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            long days = Math.round((f.parse(d).getTime() - f.parse(td).getTime()) / 86400000.0);
            if (days < 0) return "Atrasado";
            if (days == 0) return "Hoy";
            if (days == 1) return "Mañana";
            Calendar c = Calendar.getInstance();
            c.setTime(f.parse(d));
            return DIAS[c.get(Calendar.DAY_OF_WEEK) - 1].substring(0, 3) + " " + c.get(Calendar.DAY_OF_MONTH);
        } catch (Exception e) { return ""; }
    }

    static RemoteViews mimo(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.w_mimo);
        JSONObject d = Api.data(c, "mimi");
        boolean fresh = today().equals(d.optString("day"));
        int st = fresh || isYesterday(d.optString("day")) ? d.optInt("st", 0) : 0;
        v.setTextViewText(R.id.fire, "🔥" + st);
        v.setImageViewResource(R.id.pet, pet("mimi", d.optString("img")));
        int ht = d.optInt("ht", 0), hd = d.optInt("hd", 0);
        v.setTextViewText(R.id.title, fresh && ht > 0 ? "Hábitos de hoy · " + hd + "/" + ht : "Hábitos de hoy");
        int[] ks = {R.id.k0, R.id.k1, R.id.k2, R.id.k3, R.id.k4, R.id.k5};
        JSONArray hb = fresh ? d.optJSONArray("habits") : null;
        for (int i = 0; i < 6; i++) {
            JSONObject h = hb != null ? hb.optJSONObject(i) : null;
            if (h == null) { v.setViewVisibility(ks[i], android.view.View.GONE); continue; }
            v.setViewVisibility(ks[i], android.view.View.VISIBLE);
            int tg = h.optInt("tg", 1);
            String mark = h.optBoolean("d") ? "✅  " : tg > 1 ? "⬜ " + h.optInt("k", 0) + "/" + tg + "  " : "⬜  ";
            v.setTextViewText(ks[i], mark + h.optString("n"));
            v.setOnClickPendingIntent(ks[i], action(c, Acciones.HABITO, h.optString("id"), 100 + i));
        }
        if (hb == null || hb.length() == 0) {
            v.setViewVisibility(ks[0], android.view.View.VISIBLE);
            v.setTextViewText(ks[0], fresh ? "Aún no tienes hábitos para hoy. Toca para crear uno 💗" : "Abre Mimo un momento para actualizar 🐾");
            v.setOnClickPendingIntent(ks[0], open(c, "mimo/?go=rut:habitos", 14));
        }
        Calendar cal = Calendar.getInstance();
        boolean morning = cal.get(Calendar.HOUR_OF_DAY) < 15;
        boolean done = morning ? d.optBoolean("am") : d.optBoolean("pm");
        v.setTextViewText(R.id.skin, (morning ? "☀️ " : "🌙 ") + (done ? "Skincare ✓" : "Skincare"));
        v.setTextViewText(R.id.move, fresh ? d.optString("move", "🤸 Moverme") : "🤸 Moverme");
        v.setOnClickPendingIntent(R.id.root, open(c, "mimo/?go=rut:habitos", 11));
        v.setOnClickPendingIntent(R.id.skin, open(c, "mimo/?go=cui:piel", 12));
        v.setOnClickPendingIntent(R.id.move, open(c, "mimo/?go=rut:mover", 13));
        return v;
    }

    static RemoteViews racha(Context c, String app) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.w_racha);
        JSONObject d = Api.data(c, app);
        boolean fresh = today().equals(d.optString("day"));
        boolean hot = fresh && d.optBoolean("hot");
        int st = fresh || isYesterday(d.optString("day")) ? d.optInt("st", 0) : 0;
        v.setInt(R.id.root, "setBackgroundResource", hot ? R.drawable.bg_fire : R.drawable.bg_cold);
        v.setImageViewResource(R.id.pet, pet(app, hot ? (st >= 3 ? "celebrando" : "feliz") : (st > 0 ? "pensativo" : "triste")));
        v.setTextViewText(R.id.fire, "🔥 " + st);
        String nm = app.equals("doki") ? "Doki" : "Mimo";
        v.setTextViewText(R.id.msg, hot ? "¡Racha a salvo hoy!" : st > 0 ? "¡Tu racha se apaga! Anota algo" : "Empieza tu racha hoy");
        v.setOnClickPendingIntent(R.id.root, open(c, app.equals("doki") ? "doki/?go=age:hoy" : app.equals("cuki") ? "cuki/?go=est:repaso" : "mimo/?go=rut:habitos", app.equals("doki") ? 21 : app.equals("cuki") ? 23 : 22));
        return v;
    }

    static boolean isYesterday(String day) {
        Calendar y = Calendar.getInstance();
        y.add(Calendar.DAY_OF_MONTH, -1);
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(y.getTime()).equals(day);
    }
}
