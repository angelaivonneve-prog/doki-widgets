package pe.angela.dokimimo;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.View;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/** Widgets estilo Agenda Escolar: horario del día, semana, pendientes con calendario y Cuki. */
public class Widgets2 {
    static final String[] D3 = {"Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"};
    static final String[] D1 = {"D", "L", "M", "M", "J", "V", "S"};
    static final String[] MES = {"ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "set", "oct", "nov", "dic"};
    static final SimpleDateFormat F = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

    static int id(Context c, String name) { return c.getResources().getIdentifier(name, "id", c.getPackageName()); }
    static int col(String s, String def) { try { return Color.parseColor(s == null || s.isEmpty() ? def : s); } catch (Exception e) { return Color.parseColor(def); } }
    /** Mezcla el color con blanco para que el bloque sea pastel y el texto se lea. */
    static int soft(int c, float k) { int r = Color.red(c), g = Color.green(c), b = Color.blue(c); return Color.rgb((int) (r + (255 - r) * k), (int) (g + (255 - g) * k), (int) (b + (255 - b) * k)); }

    static int[] size(Context c, int wid) {
        Bundle o = AppWidgetManager.getInstance(c).getAppWidgetOptions(wid);
        int w = o == null ? 0 : o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0), h = o == null ? 0 : o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        return new int[]{w == 0 ? 300 : w, h == 0 ? 300 : h};
    }

    static void bindList(Context c, RemoteViews v, int listId, int emptyId, String kind, int wid, String openPath, int req) {
        Intent i = new Intent(c, Lists.class).putExtra("k", kind).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid);
        i.setData(Uri.parse("dm://" + kind + "/" + wid));
        v.setRemoteAdapter(listId, i);
        if (emptyId != 0) v.setEmptyView(listId, emptyId);
        Intent o = new Intent(Intent.ACTION_VIEW, Uri.parse(Widgets.url(openPath)));
        o.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        v.setPendingIntentTemplate(listId, PendingIntent.getActivity(c, req, o, PendingIntent.FLAG_MUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
    }

    static void renderAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, HorarioWidget.class));
        for (int i : ids) m.updateAppWidget(i, horario(c, i));
        if (ids.length > 0) m.notifyAppWidgetViewDataChanged(ids, R.id.list);
        ids = m.getAppWidgetIds(new ComponentName(c, SemanaWidget.class));
        for (int i : ids) m.updateAppWidget(i, semana(c, i));
        if (ids.length > 0) for (int k = 0; k < 6; k++) m.notifyAppWidgetViewDataChanged(ids, id(c, "l" + k));
        ids = m.getAppWidgetIds(new ComponentName(c, PendSemWidget.class));
        for (int i : ids) m.updateAppWidget(i, pendSem(c, i));
        if (ids.length > 0) m.notifyAppWidgetViewDataChanged(ids, R.id.list);
        for (int i : m.getAppWidgetIds(new ComponentName(c, CukiWidget.class))) m.updateAppWidget(i, cuki(c, i));
        for (int i : m.getAppWidgetIds(new ComponentName(c, RachaCukiWidget.class))) m.updateAppWidget(i, Widgets.small(c, i, Widgets.racha(c, "cuki")));
    }

    /* ---------------- Horario del día (con flechas para ver otros días) ---------------- */
    static RemoteViews horario(Context c, int wid) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.w_horario);
        int off = Api.prefs(c).getInt("hOff", 0);
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, off);
        int dow = cal.get(Calendar.DAY_OF_WEEK) - 1;
        String lbl = off == 0 ? "Hoy · " : off == 1 ? "Mañana · " : off == -1 ? "Ayer · " : "";
        v.setTextViewText(R.id.title, lbl + Widgets.DIAS[dow]);
        v.setTextViewText(R.id.sub, cal.get(Calendar.DAY_OF_MONTH) + " de " + MES[cal.get(Calendar.MONTH)]);
        v.setViewVisibility(R.id.hoy, off == 0 ? View.GONE : View.VISIBLE);
        JSONObject d = Api.data(c, "doki");
        v.setTextViewText(R.id.empty, d.length() == 0 ? "Abre Doki y entra con tu correo." : "Sin clases este día 🎉");
        bindList(c, v, R.id.list, R.id.empty, "hor", wid, "doki/?go=age:horario", 205);
        int[] z = size(c, wid);
        v.setViewVisibility(R.id.sub, z[1] < 140 ? View.GONE : View.VISIBLE);
        v.setOnClickPendingIntent(R.id.prev, Widgets.action(c, Acciones.H_PREV, null, 201));
        v.setOnClickPendingIntent(R.id.next, Widgets.action(c, Acciones.H_NEXT, null, 202));
        v.setOnClickPendingIntent(R.id.hoy, Widgets.action(c, Acciones.H_HOY, null, 203));
        v.setOnClickPendingIntent(R.id.root, Widgets.open(c, "doki/?go=age:horario", 204));
        return v;
    }

    /* ---------------- Semana (Lunes a Sábado), cada día con su lista ---------------- */
    static RemoteViews semana(Context c, int wid) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.w_semana);
        Calendar cal = Calendar.getInstance();
        int today = cal.get(Calendar.DAY_OF_WEEK) - 1;
        Calendar mon = (Calendar) cal.clone();
        mon.add(Calendar.DAY_OF_MONTH, -((today + 6) % 7));
        JSONObject d = Api.data(c, "doki");
        v.setTextViewText(R.id.title, d.length() == 0 ? "Mi semana · abre Doki para verla" : "Mi semana · " + mon.get(Calendar.DAY_OF_MONTH) + " " + MES[mon.get(Calendar.MONTH)]);
        int[] z = size(c, wid);
        boolean narrow = z[0] < 300;
        v.setViewVisibility(R.id.title, z[1] < 150 ? View.GONE : View.VISIBLE);
        for (int k = 0; k < 6; k++) {
            int dow = k + 1;
            Calendar dc = (Calendar) mon.clone();
            dc.add(Calendar.DAY_OF_MONTH, k);
            int sd = id(c, "sd" + k);
            v.setTextViewText(sd, (narrow ? D1[dow] + "" : D3[dow] + " ") + dc.get(Calendar.DAY_OF_MONTH));
            boolean isT = dow == today;
            v.setInt(sd, "setBackgroundResource", isT ? R.drawable.bg_today : 0);
            v.setTextColor(sd, isT ? Color.WHITE : Color.parseColor("#3B2F3F"));
            bindList(c, v, id(c, "l" + k), 0, "sem" + k, wid, "doki/?go=age:horario", 260 + k);
        }
        v.setOnClickPendingIntent(R.id.root, Widgets.open(c, "doki/?go=age:horario", 211));
        return v;
    }

    /* ---------------- Pendientes con calendario semanal ---------------- */
    static RemoteViews pendSem(Context c, int wid) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.w_pendsem);
        JSONObject d = Api.data(c, "doki");
        JSONArray tl = d.optJSONArray("tl");
        String td = Widgets.today(), sel = Api.prefs(c).getString("pSel", "");
        Calendar cal = Calendar.getInstance();
        int today = cal.get(Calendar.DAY_OF_WEEK) - 1;
        Calendar mon = (Calendar) cal.clone();
        mon.add(Calendar.DAY_OF_MONTH, -((today + 6) % 7));
        int late = 0, total = tl == null ? 0 : tl.length(), selN = 0;
        for (int i = 0; tl != null && i < tl.length(); i++) { JSONObject t = tl.optJSONObject(i); if (t == null) continue; if (t.optString("d").compareTo(td) < 0) late++; if (t.optString("d").equals(sel)) selN++; }
        for (int k = 0; k < 7; k++) {
            Calendar dc = (Calendar) mon.clone();
            dc.add(Calendar.DAY_OF_MONTH, k);
            String key = F.format(dc.getTime());
            int cnt = 0;
            for (int i = 0; tl != null && i < tl.length(); i++) { JSONObject t = tl.optJSONObject(i); if (t != null && key.equals(t.optString("d"))) cnt++; }
            v.setTextViewText(id(c, "dl" + k), D1[(k + 1) % 7]);
            v.setTextViewText(id(c, "dn" + k), String.valueOf(dc.get(Calendar.DAY_OF_MONTH)));
            boolean isT = key.equals(td);
            v.setInt(id(c, "dn" + k), "setBackgroundResource", isT ? R.drawable.bg_today : 0);
            v.setTextColor(id(c, "dn" + k), isT ? Color.WHITE : key.compareTo(td) < 0 ? Color.parseColor("#A9A3AD") : Color.parseColor("#3B2F3F"));
            v.setTextViewText(id(c, "dd" + k), cnt == 0 ? " " : cnt > 3 ? "•••+" : "•••".substring(0, cnt));
            v.setInt(id(c, "dc" + k), "setBackgroundResource", key.equals(sel) ? R.drawable.bg_sel : 0);
            v.setOnClickPendingIntent(id(c, "dc" + k), Widgets.action(c, Acciones.P_DAY, key, 220 + k));
        }
        String selTxt;
        if (sel.isEmpty()) selTxt = "PRÓXIMOS" + (late > 0 ? " · " + late + " atrasado" + (late == 1 ? "" : "s") : "") + " · toca un día";
        else { String t = sel; try { Calendar sc = Calendar.getInstance(); sc.setTime(F.parse(sel)); t = Widgets.DIAS[sc.get(Calendar.DAY_OF_WEEK) - 1].toUpperCase() + " " + sc.get(Calendar.DAY_OF_MONTH); } catch (Exception ignored) {} selTxt = t + " · " + selN + " · toca otra vez para ver todos"; }
        v.setTextViewText(R.id.sel, selTxt);
        v.setTextViewText(R.id.title, total == 0 ? "Pendientes" : "Pendientes · " + total);
        v.setTextViewText(R.id.empty, d.length() == 0 ? "Abre Doki y entra con tu correo." : sel.isEmpty() ? "¡Nada pendiente! 🎉" : "Nada este día 🎉");
        v.setImageViewResource(R.id.pet, Widgets.pet("doki", late > 0 ? "pensativo" : total == 0 ? "celebrando" : "feliz"));
        bindList(c, v, R.id.list, R.id.empty, "psem", wid, "doki/?go=age:pend", 233);
        int[] z = size(c, wid);
        v.setViewVisibility(R.id.strip, z[1] < 130 ? View.GONE : View.VISIBLE);
        v.setViewVisibility(R.id.sel, z[1] < 130 ? View.GONE : View.VISIBLE);
        v.setViewVisibility(R.id.pet, z[0] < 200 ? View.GONE : View.VISIBLE);
        v.setOnClickPendingIntent(R.id.add, Widgets.open(c, "doki/?new=task", 231));
        v.setOnClickPendingIntent(R.id.root, Widgets.open(c, "doki/?go=age:pend", 232));
        return v;
    }

    /* ---------------- Cuki: lo que tienes que recordar ---------------- */
    static RemoteViews cuki(Context c, int wid) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.w_cuki);
        JSONObject d = Api.data(c, "cuki");
        boolean fresh = Widgets.today().equals(d.optString("day"));
        int st = fresh || Widgets.isYesterday(d.optString("day")) ? d.optInt("st", 0) : 0;
        v.setTextViewText(R.id.fire, "🔥" + st);
        int q = fresh ? d.optInt("q", 0) : d.optInt("due", 0);
        v.setImageViewResource(R.id.pet, Widgets.pet("cuki", d.length() == 0 ? "saludando" : q > 0 ? "pensativo" : "celebrando"));
        v.setTextViewText(R.id.st, d.length() == 0 ? "Abre Cuki y entra con tu correo" : (q > 0 ? "🃏 " + q + " tarjeta" + (q == 1 ? "" : "s") + " por repasar" : "🃏 Repaso al día ✓") + " · ⏰ " + d.optString("sa", "8 pm"));
        JSONObject card = d.optJSONObject("card");
        SharedPreferences p = Api.prefs(c);
        boolean flip = card != null && card.optString("q").equals(p.getString("ckFlip", ""));
        if (card != null) {
            v.setTextViewText(R.id.lbl, "🃏 TARJETA RÁPIDA · " + (flip ? "toca para ocultar" : "toca para ver la respuesta"));
            v.setTextViewText(R.id.q, card.optString("q"));
            v.setTextViewText(R.id.a, flip ? card.optString("a") : "");
            v.setViewVisibility(R.id.a, flip ? View.VISIBLE : View.GONE);
            v.setOnClickPendingIntent(R.id.card, Widgets.action(c, Acciones.CK_FLIP, card.optString("q"), 241));
        } else {
            v.setTextViewText(R.id.lbl, "💊 PÍLDORA DEL DÍA · " + d.optString("pp", "").toUpperCase());
            v.setTextViewText(R.id.q, d.length() == 0 ? "Aquí verás tu tarjeta del día y tu píldora de conocimiento 🐹" : d.optString("pill"));
            v.setViewVisibility(R.id.a, View.GONE);
            v.setOnClickPendingIntent(R.id.card, Widgets.open(c, "cuki/?go=est:choy", 242));
        }
        StringBuilder r = new StringBuilder();
        JSONArray ap = fresh ? d.optJSONArray("ap") : null, ex = d.optJSONArray("ex");
        if (ap != null && ap.length() > 0) r.append("📸 Sube tus apuntes de ").append(ap.optString(0)).append(ap.length() > 1 ? " (+" + (ap.length() - 1) + ")" : "");
        if (ex != null && ex.length() > 0) r.append(r.length() > 0 ? "\n" : "").append("🧠 ").append(ex.optString(0));
        if (r.length() == 0 && d.length() > 0) r.append(fresh && d.optBoolean("eng") ? "🇬🇧 Inglés de hoy ✓" : "🇬🇧 Tu lección de inglés te espera");
        v.setTextViewText(R.id.rem, r.toString());
        v.setTextViewText(R.id.b3, fresh && d.optBoolean("eng") ? "🇬🇧 Inglés ✓" : "🇬🇧 Inglés");
        v.setOnClickPendingIntent(R.id.b1, Widgets.open(c, "cuki/?go=est:repaso", 243));
        v.setOnClickPendingIntent(R.id.b2, Widgets.open(c, "cuki/?go=apu:nuevo", 244));
        v.setOnClickPendingIntent(R.id.b3, Widgets.open(c, "cuki/?go=ing:leccion", 245));
        v.setOnClickPendingIntent(R.id.root, Widgets.open(c, "cuki/?go=est:choy", 246));
        int[] z = size(c, wid);
        v.setViewVisibility(R.id.card, z[1] < 130 ? View.GONE : View.VISIBLE);
        v.setViewVisibility(R.id.rem, z[1] < 175 || r.length() == 0 ? View.GONE : View.VISIBLE);
        boolean nar = z[0] < 230;
        v.setTextViewText(R.id.b1, nar ? "🃏" : "🃏 Repasar");
        v.setTextViewText(R.id.b2, nar ? "📸" : "📸 Apunte");
        if (nar) v.setTextViewText(R.id.b3, "🇬🇧");
        v.setViewVisibility(R.id.fire, z[0] < 180 ? View.GONE : View.VISIBLE);
        return v;
    }
}
