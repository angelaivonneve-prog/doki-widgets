package pe.angela.dokimimo;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.View;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/** Widgets estilo Agenda Escolar: horario del día, semana, pendientes con calendario y Cuki. */
public class Widgets2 {
    static final String[] D3 = {"Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"};
    static final String[] D1 = {"D", "L", "M", "M", "J", "V", "S"};
    static final String[] MES = {"ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "set", "oct", "nov", "dic"};
    static final SimpleDateFormat F = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

    static int id(Context c, String name) { return c.getResources().getIdentifier(name, "id", c.getPackageName()); }
    static int col(String s, String def) { try { return Color.parseColor(s == null || s.isEmpty() ? def : s); } catch (Exception e) { return Color.parseColor(def); } }
    /** Mezcla el color con blanco para que el bloque sea pastel y el texto se lea. */
    static int soft(int c, float k) { int r = Color.red(c), g = Color.green(c), b = Color.blue(c); return Color.rgb((int) (r + (255 - r) * k), (int) (g + (255 - g) * k), (int) (b + (255 - b) * k)); }

    static void renderAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        for (int i : m.getAppWidgetIds(new ComponentName(c, HorarioWidget.class))) m.updateAppWidget(i, horario(c));
        for (int i : m.getAppWidgetIds(new ComponentName(c, SemanaWidget.class))) m.updateAppWidget(i, semana(c));
        for (int i : m.getAppWidgetIds(new ComponentName(c, PendSemWidget.class))) m.updateAppWidget(i, pendSem(c));
        for (int i : m.getAppWidgetIds(new ComponentName(c, CukiWidget.class))) m.updateAppWidget(i, cuki(c));
        for (int i : m.getAppWidgetIds(new ComponentName(c, RachaCukiWidget.class))) m.updateAppWidget(i, Widgets.racha(c, "cuki"));
    }

    /* ---------------- Horario del día (con flechas para ver otros días) ---------------- */
    static RemoteViews horario(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.w_horario);
        SharedPreferences p = Api.prefs(c);
        int off = p.getInt("hOff", 0);
        Calendar cal = Calendar.getInstance();
        int nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE);
        cal.add(Calendar.DAY_OF_MONTH, off);
        int dow = cal.get(Calendar.DAY_OF_WEEK) - 1;
        String lbl = off == 0 ? "Hoy" : off == 1 ? "Mañana" : off == -1 ? "Ayer" : Widgets.DIAS[dow];
        v.setTextViewText(R.id.title, off == 0 || off == 1 || off == -1 ? lbl + " · " + Widgets.DIAS[dow] : Widgets.DIAS[dow]);
        v.setTextViewText(R.id.sub, cal.get(Calendar.DAY_OF_MONTH) + " de " + MES[cal.get(Calendar.MONTH)]);
        v.setViewVisibility(R.id.hoy, off == 0 ? View.GONE : View.VISIBLE);
        JSONObject d = Api.data(c, "doki"), week = d.optJSONObject("week");
        JSONArray items = week == null ? null : week.optJSONArray(String.valueOf(dow));
        int n = 0, total = items == null ? 0 : items.length();
        for (int i = 0; i < total && n < 8; i++) {
            JSONObject it = items.optJSONObject(i);
            if (it == null) continue;
            boolean past = off == 0 && it.optInt("e", 0) <= nowMin, now = off == 0 && !past && it.optInt("s", 0) <= nowMin;
            v.setViewVisibility(id(c, "hr" + n), View.VISIBLE);
            v.setTextViewText(id(c, "ht" + n), it.optString("h") + "\n" + it.optString("f"));
            int cc = col(it.optString("c"), "#F6B4C6");
            v.setInt(id(c, "hb" + n), "setBackgroundColor", past ? soft(cc, .6f) : cc);
            v.setInt(id(c, "hx" + n), "setBackgroundColor", now ? soft(cc, .65f) : Color.TRANSPARENT);
            v.setTextViewText(id(c, "hn" + n), it.optString("n"));
            v.setTextColor(id(c, "hn" + n), past ? Color.parseColor("#A9A3AD") : Color.parseColor("#3B2F3F"));
            String sub = now ? "● Ahora · termina " + it.optString("f") : past ? "Terminó" : it.optString("p");
            v.setTextViewText(id(c, "hs" + n), sub);
            v.setViewVisibility(id(c, "hs" + n), sub.isEmpty() ? View.GONE : View.VISIBLE);
            n++;
        }
        for (int i = n; i < 8; i++) v.setViewVisibility(id(c, "hr" + i), View.GONE);
        v.setTextViewText(R.id.empty, d.length() == 0 ? "Abre Doki y entra con tu correo para ver tu horario." : n == 0 ? "Sin clases este día 🎉" : total > 8 ? "+" + (total - 8) + " más" : "");
        v.setOnClickPendingIntent(R.id.prev, Widgets.action(c, Acciones.H_PREV, null, 201));
        v.setOnClickPendingIntent(R.id.next, Widgets.action(c, Acciones.H_NEXT, null, 202));
        v.setOnClickPendingIntent(R.id.hoy, Widgets.action(c, Acciones.H_HOY, null, 203));
        v.setOnClickPendingIntent(R.id.root, Widgets.open(c, "doki/?go=age:horario", 204));
        return v;
    }

    /* ---------------- Semana (Lunes a Sábado) ---------------- */
    static RemoteViews semana(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.w_semana);
        JSONObject d = Api.data(c, "doki"), week = d.optJSONObject("week");
        Calendar cal = Calendar.getInstance();
        int today = cal.get(Calendar.DAY_OF_WEEK) - 1, nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE);
        Calendar mon = (Calendar) cal.clone();
        mon.add(Calendar.DAY_OF_MONTH, -((today + 6) % 7));
        v.setTextViewText(R.id.title, "Mi semana · " + mon.get(Calendar.DAY_OF_MONTH) + " " + MES[mon.get(Calendar.MONTH)]);
        v.setTextViewText(R.id.upd, d.length() == 0 ? "Abre Doki" : "");
        for (int k = 0; k < 6; k++) {
            int dow = k + 1;
            Calendar dc = (Calendar) mon.clone();
            dc.add(Calendar.DAY_OF_MONTH, k);
            int sd = id(c, "sd" + k);
            v.setTextViewText(sd, D3[dow] + " " + dc.get(Calendar.DAY_OF_MONTH));
            boolean isT = dow == today;
            v.setInt(sd, "setBackgroundResource", isT ? R.drawable.bg_today : 0);
            v.setTextColor(sd, isT ? Color.WHITE : Color.parseColor("#3B2F3F"));
            JSONArray items = week == null ? null : week.optJSONArray(String.valueOf(dow));
            int n = items == null ? 0 : items.length();
            for (int j = 0; j < 7; j++) {
                int cid = id(c, "c" + k + "_" + j);
                if (j >= n) { v.setViewVisibility(cid, View.GONE); continue; }
                JSONObject it = items.optJSONObject(j);
                if (j == 6 && n > 7) { v.setViewVisibility(cid, View.VISIBLE); v.setTextViewText(cid, "+" + (n - 6)); v.setInt(cid, "setBackgroundColor", Color.TRANSPARENT); continue; }
                v.setViewVisibility(cid, View.VISIBLE);
                String nm = it.optString("sn", it.optString("n"));
                v.setTextViewText(cid, it.optString("h").replace(" am", "a").replace(" pm", "p") + " " + nm);
                int cc = col(it.optString("c"), "#F6B4C6");
                boolean past = isT && it.optInt("e", 0) <= nowMin;
                v.setInt(cid, "setBackgroundColor", soft(cc, past ? .75f : .35f));
                v.setTextColor(cid, past ? Color.parseColor("#A9A3AD") : Color.parseColor("#3B2F3F"));
            }
        }
        v.setOnClickPendingIntent(R.id.root, Widgets.open(c, "doki/?go=age:horario", 211));
        return v;
    }

    /* ---------------- Pendientes con calendario semanal ---------------- */
    static RemoteViews pendSem(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.w_pendsem);
        JSONObject d = Api.data(c, "doki");
        JSONArray tl = d.optJSONArray("tl");
        String td = Widgets.today(), sel = Api.prefs(c).getString("pSel", "");
        Calendar cal = Calendar.getInstance();
        int today = cal.get(Calendar.DAY_OF_WEEK) - 1;
        Calendar mon = (Calendar) cal.clone();
        mon.add(Calendar.DAY_OF_MONTH, -((today + 6) % 7));
        String[] keys = new String[7];
        int late = 0;
        for (int i = 0; tl != null && i < tl.length(); i++) { JSONObject t = tl.optJSONObject(i); if (t != null && t.optString("d").compareTo(td) < 0) late++; }
        for (int k = 0; k < 7; k++) {
            Calendar dc = (Calendar) mon.clone();
            dc.add(Calendar.DAY_OF_MONTH, k);
            keys[k] = F.format(dc.getTime());
            int cnt = 0;
            for (int i = 0; tl != null && i < tl.length(); i++) { JSONObject t = tl.optJSONObject(i); if (t != null && keys[k].equals(t.optString("d"))) cnt++; }
            v.setTextViewText(id(c, "dl" + k), D1[(k + 1) % 7]);
            v.setTextViewText(id(c, "dn" + k), String.valueOf(dc.get(Calendar.DAY_OF_MONTH)));
            boolean isT = keys[k].equals(td);
            v.setInt(id(c, "dn" + k), "setBackgroundResource", isT ? R.drawable.bg_today : 0);
            v.setTextColor(id(c, "dn" + k), isT ? Color.WHITE : keys[k].compareTo(td) < 0 ? Color.parseColor("#A9A3AD") : Color.parseColor("#3B2F3F"));
            v.setTextViewText(id(c, "dd" + k), cnt == 0 ? " " : cnt > 3 ? "•••+" : "•••".substring(0, cnt));
            v.setInt(id(c, "dc" + k), "setBackgroundResource", keys[k].equals(sel) ? R.drawable.bg_sel : 0);
            v.setOnClickPendingIntent(id(c, "dc" + k), Widgets.action(c, Acciones.P_DAY, keys[k], 220 + k));
        }
        List<JSONObject> show = new ArrayList<>();
        for (int i = 0; tl != null && i < tl.length(); i++) {
            JSONObject t = tl.optJSONObject(i);
            if (t == null) continue;
            if (sel.isEmpty() || sel.equals(t.optString("d"))) show.add(t);
        }
        if (sel.isEmpty()) v.setTextViewText(R.id.sel, "PRÓXIMOS" + (late > 0 ? " · " + late + " atrasado" + (late == 1 ? "" : "s") : ""));
        else {
            try { Calendar sc = Calendar.getInstance(); sc.setTime(F.parse(sel)); v.setTextViewText(R.id.sel, (sel.equals(td) ? "HOY · " : "") + Widgets.DIAS[sc.get(Calendar.DAY_OF_WEEK) - 1].toUpperCase() + " " + sc.get(Calendar.DAY_OF_MONTH) + " · toca de nuevo para ver todos"); } catch (Exception e) { v.setTextViewText(R.id.sel, ""); }
        }
        int n = 0;
        for (JSONObject t : show) {
            if (n >= 5) break;
            v.setViewVisibility(id(c, "q" + n), View.VISIBLE);
            v.setInt(id(c, "qc" + n), "setBackgroundColor", col(t.optString("c"), "#F6B4C6"));
            v.setTextViewText(id(c, "qt" + n), t.optString("t"));
            boolean isLate = t.optString("d").compareTo(td) < 0;
            String when = sel.isEmpty() ? Widgets.whenLabel(t.optString("d"), td) : "";
            String h = t.optString("h");
            v.setTextViewText(id(c, "qw" + n), (when + (h.isEmpty() ? "" : (when.isEmpty() ? "" : " · ") + h)));
            v.setTextColor(id(c, "qw" + n), isLate ? Color.parseColor("#D9363E") : Color.parseColor("#6E6873"));
            n++;
        }
        for (int i = n; i < 5; i++) v.setViewVisibility(id(c, "q" + i), View.GONE);
        int total = tl == null ? 0 : tl.length();
        v.setTextViewText(R.id.title, total == 0 ? "Pendientes" : "Pendientes · " + total);
        v.setTextViewText(R.id.empty, d.length() == 0 ? "Abre Doki y entra con tu correo para ver tus pendientes." : show.isEmpty() ? (sel.isEmpty() ? "¡Nada pendiente! 🎉" : "Nada este día 🎉") : show.size() > 5 ? "+" + (show.size() - 5) + " más" : "");
        v.setImageViewResource(R.id.pet, Widgets.pet("doki", late > 0 ? "pensativo" : total == 0 ? "celebrando" : "feliz"));
        v.setOnClickPendingIntent(R.id.add, Widgets.open(c, "doki/?new=task", 231));
        v.setOnClickPendingIntent(R.id.root, Widgets.open(c, "doki/?go=age:pend", 232));
        return v;
    }

    /* ---------------- Cuki: lo que tienes que recordar ---------------- */
    static RemoteViews cuki(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.w_cuki);
        JSONObject d = Api.data(c, "cuki");
        boolean fresh = Widgets.today().equals(d.optString("day"));
        int st = fresh || Widgets.isYesterday(d.optString("day")) ? d.optInt("st", 0) : 0;
        v.setTextViewText(R.id.fire, "🔥" + st);
        int q = fresh ? d.optInt("q", 0) : d.optInt("due", 0);
        v.setImageViewResource(R.id.pet, Widgets.pet("cuki", d.length() == 0 ? "saludando" : q > 0 ? "pensativo" : "celebrando"));
        v.setTextViewText(R.id.st, d.length() == 0 ? "Abre Cuki y entra con tu correo" : (q > 0 ? "🃏 " + q + " tarjeta" + (q == 1 ? "" : "s") + " por repasar" : "🃏 Repaso al día ✓") + " · ⏰ " + d.optString("sa", "8 pm"));
        JSONObject card = d.optJSONObject("card");
        SharedPreferences p = Api.prefs(c);
        boolean flip = card != null && card.optString("q").equals(p.getString("ckFlip", ""));
        if (card != null) {
            v.setTextViewText(R.id.lbl, "🃏 TARJETA RÁPIDA · " + (flip ? "toca para ocultar" : "toca para ver la respuesta"));
            v.setTextViewText(R.id.q, card.optString("q"));
            v.setTextViewText(R.id.a, flip ? card.optString("a") : "");
            v.setViewVisibility(R.id.a, flip ? View.VISIBLE : View.GONE);
            v.setOnClickPendingIntent(R.id.card, Widgets.action(c, Acciones.CK_FLIP, card.optString("q"), 241));
        } else {
            v.setTextViewText(R.id.lbl, "💊 PÍLDORA DEL DÍA · " + d.optString("pp", "").toUpperCase());
            v.setTextViewText(R.id.q, d.length() == 0 ? "Aquí verás tu tarjeta del día y tu píldora de conocimiento 🐹" : d.optString("pill"));
            v.setViewVisibility(R.id.a, View.GONE);
            v.setOnClickPendingIntent(R.id.card, Widgets.open(c, "cuki/?go=est:choy", 242));
        }
        StringBuilder r = new StringBuilder();
        JSONArray ap = fresh ? d.optJSONArray("ap") : null, ex = d.optJSONArray("ex");
        if (ap != null && ap.length() > 0) r.append("📸 Sube tus apuntes de ").append(ap.optString(0)).append(ap.length() > 1 ? " (+" + (ap.length() - 1) + ")" : "");
        if (ex != null && ex.length() > 0) r.append(r.length() > 0 ? "\n" : "").append("🧠 ").append(ex.optString(0));
        if (r.length() == 0 && d.length() > 0) r.append(fresh && d.optBoolean("eng") ? "🇬🇧 Inglés de hoy ✓" : "🇬🇧 Tu lección de inglés te espera");
        v.setTextViewText(R.id.rem, r.toString());
        v.setTextViewText(R.id.b3, fresh && d.optBoolean("eng") ? "🇬🇧 Inglés ✓" : "🇬🇧 Inglés");
        v.setOnClickPendingIntent(R.id.b1, Widgets.open(c, "cuki/?go=est:repaso", 243));
        v.setOnClickPendingIntent(R.id.b2, Widgets.open(c, "cuki/?go=apu:nuevo", 244));
        v.setOnClickPendingIntent(R.id.b3, Widgets.open(c, "cuki/?go=ing:leccion", 245));
        v.setOnClickPendingIntent(R.id.root, Widgets.open(c, "cuki/?go=est:choy", 246));
        return v;
    }
}
