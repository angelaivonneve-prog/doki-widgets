package pe.angela.dokimimo;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;

/** Cada 15 minutos trae lo nuevo de la nube y redibuja los widgets. */
public class SyncJob extends JobService {
    static void schedule(Context c) {
        JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (js == null || js.getPendingJob(7) != null) return;
        try {
            js.schedule(new JobInfo.Builder(7, new ComponentName(c, SyncJob.class))
                    .setPeriodic(15 * 60 * 1000L).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPersisted(true).build());
        } catch (Throwable e) {
            // Si el teléfono no deja pedir "con internet", se programa igual sin esa condición
            try { js.schedule(new JobInfo.Builder(7, new ComponentName(c, SyncJob.class)).setPeriodic(15 * 60 * 1000L).setPersisted(true).build()); } catch (Throwable ignored) {}
        }
    }

    static void now(Context c) {
        final Context a = c.getApplicationContext();
        new Thread(() -> { try { Api.fetch(a); Widgets.renderAll(a); } catch (Throwable ignored) {} }).start();
    }

    @Override public boolean onStartJob(JobParameters p) {
        new Thread(() -> { try { Api.fetch(this); Widgets.renderAll(this); } catch (Throwable ignored) {} jobFinished(p, false); }).start();
        return true;
    }

    @Override public boolean onStopJob(JobParameters p) { return true; }
}
