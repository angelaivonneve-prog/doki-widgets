package pe.angela.dokimimo;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

/** Puente invisible: al tocar una fila de una lista del widget, abre la app correcta. (Android 14 no deja que la lista abra la web directo.) */
public class Abrir extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        String u = getIntent().getStringExtra("u");
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(u == null ? Api.SITE : u));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception ignored) {}
        finish();
    }
}
