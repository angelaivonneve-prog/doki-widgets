package pe.angela.dokimimo;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.View;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/** Listas con scroll dentro de los widgets: se adaptan a cualquier tamaño. */
public class Lists extends RemoteViewsService {
    static class It { String t = "", n = "", s = ""; int c = Color.parseColor("#F6B4C6"); boolean past, now, late; int lay; }

    static String shortH(String h) { return h == null ? "" : h.replace(" am", "a").replace(" pm", "p"); }

    /** Arma la lista según el tipo de widget. */
    static List<It> build(Context c, String k) {
        List<It> out = new ArrayList<>();
        Calendar cal = Calendar.getInstance();
        int nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE), today = cal.get(Calendar.DAY_OF_WEEK) - 1;
        JSONObject d = Api.data(c, "doki"), week = d.optJSONObject("week");
        String td = Widgets.today();
        if (k.equals("hor") || k.equals("dia")) {
            int off = k.equals("hor") ? Api.prefs(c).getInt("hOff", 0) : 0;
            Calendar dc = (Calendar) cal.clone();
            dc.add(Calendar.DAY_OF_MONTH, off);
            int dow = dc.get(Calendar.DAY_OF_WEEK) - 1;
            JSONArray a = week == null ? null : week.optJSONArray(String.valueOf(dow));
            for (int i = 0; a != null && i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                It it = new It();
                it.lay = R.layout.it_clase;
                it.past = off == 0 && o.optInt("e", 0) <= nowMin;
                it.now = off == 0 && !it.past && o.optInt("s", 0) <= nowMin;
                if (k.equals("dia") && it.past) continue;
                it.t = shortH(o.optString("h"));
                it.n = o.optString("n");
                it.s = it.now ? "● Ahora · hasta " + o.optString("f") : (it.past ? "Terminó" : "hasta " + o.optString("f") + (o.optString("p").isEmpty() ? "" : " · " + o.optString("p")));
                it.c = Widgets2.col(o.optString("c"), "#F6B4C6");
                out.add(it);
            }
            if (k.equals("dia") && td.equals(d.optString("day"))) {
                JSONArray ts = d.optJSONArray("tasks");
                for (int i = 0; ts != null && i < ts.length(); i++) {
                    It it = new It();
                    it.lay = R.layout.it_pend;
                    it.n = "📝 " + ts.optString(i);
                    it.c = Color.parseColor("#FFD3B8");
                    out.add(it);
                }
            }
        } else if (k.equals("pend") || k.equals("psem")) {
            String sel = k.equals("psem") ? Api.prefs(c).getString("pSel", "") : "";
            JSONArray tl = d.optJSONArray("tl");
            for (int i = 0; tl != null && i < tl.length(); i++) {
                JSONObject t = tl.optJSONObject(i);
                if (t == null || (!sel.isEmpty() && !sel.equals(t.optString("d")))) continue;
                It it = new It();
                it.lay = R.layout.it_pend;
                it.n = t.optString("t");
                it.late = t.optString("d").compareTo(td) < 0;
                String when = sel.isEmpty() ? Widgets.whenLabel(t.optString("d"), td) : "", h = shortH(t.optString("h"));
                it.s = when + (h.isEmpty() ? "" : (when.isEmpty() ? "" : " · ") + h);
                it.c = Widgets2.col(t.optString("c"), "#F6B4C6");
                out.add(it);
            }
        } else if (k.startsWith("sem")) {
            int dow = Integer.parseInt(k.substring(3)) + 1;
            JSONArray a = week == null ? null : week.optJSONArray(String.valueOf(dow));
            for (int i = 0; a != null && i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                It it = new It();
                it.lay = R.layout.it_chip;
                it.n = shortH(o.optString("h")) + " " + o.optString("sn", o.optString("n"));
                it.past = dow == today && o.optInt("e", 0) <= nowMin;
                it.c = Widgets2.col(o.optString("c"), "#F6B4C6");
                out.add(it);
            }
        }
        return out;
    }

    @Override public RemoteViewsFactory onGetViewFactory(Intent intent) {
        final String k = intent.getStringExtra("k") == null ? "pend" : intent.getStringExtra("k");
        final Context c = getApplicationContext();
        return new RemoteViewsFactory() {
            List<It> items = new ArrayList<>();
            public void onCreate() {}
            public void onDataSetChanged() { try { items = build(c, k); } catch (Throwable e) { items = new ArrayList<>(); try { Api.prefs(c).edit().putString("werr", "Lista " + k + ": " + e).apply(); } catch (Throwable ignored) {} } }
            public void onDestroy() {}
            public int getCount() { return items.size(); }
            public RemoteViews getViewAt(int i) {
                try { return view(i); } catch (Throwable e) {
                    try { Api.prefs(c).edit().putString("werr", "Fila " + k + ": " + e).apply(); } catch (Throwable ignored) {}
                    RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.it_chip);
                    v.setTextViewText(R.id.n, "…");
                    return v;
                }
            }
            RemoteViews view(int i) {
                if (i >= items.size()) return new RemoteViews(c.getPackageName(), R.layout.it_chip);
                It it = items.get(i);
                RemoteViews v = new RemoteViews(c.getPackageName(), it.lay);
                int ink = it.past ? Color.parseColor("#A9A3AD") : Color.parseColor("#3B2F3F");
                if (it.lay == R.layout.it_chip) {
                    v.setTextViewText(R.id.n, it.n);
                    v.setInt(R.id.n, "setBackgroundColor", Widgets2.soft(it.c, it.past ? .75f : .35f));
                    v.setTextColor(R.id.n, ink);
                    v.setOnClickFillInIntent(R.id.n, new Intent());
                    return v;
                }
                v.setTextViewText(R.id.n, it.n);
                v.setTextColor(R.id.n, ink);
                v.setInt(R.id.b, "setBackgroundColor", it.past ? Widgets2.soft(it.c, .6f) : it.c);
                v.setTextViewText(R.id.s, it.s);
                v.setViewVisibility(R.id.s, it.s.isEmpty() ? View.GONE : View.VISIBLE);
                if (it.late) v.setTextColor(R.id.s, Color.parseColor("#D9363E"));
                if (it.lay == R.layout.it_clase) {
                    v.setTextViewText(R.id.t, it.t);
                    v.setInt(R.id.x, "setBackgroundColor", it.now ? Widgets2.soft(it.c, .65f) : Color.TRANSPARENT);
                }
                v.setOnClickFillInIntent(R.id.it, new Intent());
                return v;
            }
            public RemoteViews getLoadingView() { return null; }
            public int getViewTypeCount() { return 3; }
            public long getItemId(int i) { return i; }
            public boolean hasStableIds() { return false; }
        };
    }
}
